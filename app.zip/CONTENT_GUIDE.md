# Content guide (for the lesson and question parts)

Files are plain JSON in `app/src/main/assets/`. Use the heading ids from `master_outline.json`
(for example `ch06-s02-t03`). Chapter ids are `ch01` ... `ch18`.

## Lessons: `assets/content/<any_name>.json`
    {
      "version": "ch01-1",
      "lessons": [
        { "headingId": "ch01-t01",
          "sections": [
            { "lang": "ur", "level": "basic", "kind": "text", "body": "..." },
            { "lang": "en", "level": "basic", "kind": "point", "body": "..." },
            { "lang": "ur", "level": "intermediate", "kind": "reference", "body": "Surah, verse: ..." }
          ] } ] }

- `lang`: `ur` or `en`. `level`: `basic`, `intermediate` or `advanced`.
- `kind`: `text` (paragraph), `point` (bullet) or `reference` (Quran/Hadith source box).
- Change `"version"` whenever the file changes, otherwise the app will not re-import it.
- Sections show in the order written. Lessons stay "Draft" until a scholar has reviewed them.

## Questions: `assets/questions/<any_name>.json`
    { "version": "ch01-1",
      "questions": [
        { "id": "q101", "chapterId": "ch01", "headingId": "ch01-t01", "difficulty": "basic",
          "textUr": "...", "textEn": "...",
          "optionsUr": ["...","...","...","..."], "optionsEn": ["...","...","...","..."],
          "correctIndex": 0, "explanationUr": "...", "explanationEn": "..." } ] }

- `id` must be unique across all files. `headingId` is optional.
- `optionsUr` and `optionsEn` need the same number of options (4 recommended).
- `correctIndex` counts from 0.

## Checking your files
The unit tests (`ContentIntegrityTest`) check ids, levels, kinds and options. The "Build APK"
workflow runs them after building the APK and uploads a `test-log` artifact.
