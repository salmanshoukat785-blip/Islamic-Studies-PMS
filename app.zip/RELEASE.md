# Release guide

## 1. Everyday test builds (already working)
Upload `app.zip` to the repo root. GitHub Actions ("Build APK") builds `app-debug.apk`.
Since Part A6 every APK is signed with the same bundled test key, so a new APK installs
**over** the old one and keeps your data. (APKs built before A6 used a random key: uninstall
them once, after making a backup in Settings > Backup and restore.)

## 2. Your own release key (do this before sharing the app widely or using Google Play)
The bundled test key is only for your own phone. Its password is inside `app/build.gradle.kts`,
so anybody who can see the repo could sign an app with it. Create a private key instead.

On a computer (or Termux with `pkg install openjdk-17`):

    keytool -genkeypair -v -storetype PKCS12 -keystore release.p12 -alias academy \
      -keyalg RSA -keysize 2048 -validity 10000

Remember the password you type (use the same one for the key). Then turn the file into text:

    base64 -w 0 release.p12        (Termux/Linux; on macOS: base64 -i release.p12)

In GitHub: repo > Settings > Secrets and variables > Actions > New repository secret. Create four:

| Secret name        | Value                           |
|--------------------|---------------------------------|
| KEYSTORE_BASE64    | the long text from base64       |
| KEYSTORE_PASSWORD  | the keystore password           |
| KEY_ALIAS          | academy (or the alias you used) |
| KEY_PASSWORD       | the key password                |

**Keep `release.p12` and the passwords safe (several copies). If you lose them you can never
update the app for people who installed it.** Never put the file or the passwords in the repo.

## 3. Build the release files
Actions > "Release APK and AAB" > Run workflow. When it finishes, download:
- `IslamicStudiesAcademy-release-apk` to share the APK directly
- `IslamicStudiesAcademy-release-aab` for Google Play

## 4. Before you publish
- Every lesson and question must be reviewed by a qualified scholar (they are drafts until then).
- Increase `versionCode` (and `versionName`) in `app/build.gradle.kts` for every release.
- Google Play needs a privacy policy page. The app collects no data and has no internet permission.
- Release builds do not shrink code (`isMinifyEnabled = false`). That is safer; turn it on later only after testing.
- The PIN is a privacy lock at app start, not strong security.

## 5. Changing the database later
The database is version 1. If you ever add or change a table or column, raise `version` in
`AppDatabase.kt` and write a `Migration` for it. Debug builds recreate the database (data is lost);
release builds do not, so a missing migration would crash the app. Make a backup first.
