# Islamic Studies Academy (Android)

Kotlin + Jetpack Compose, 100% offline, Urdu + English.

## Part A2 (this version)
- Splash screen, onboarding (language, 3 intro pages, name + level, optional 4-digit PIN)
- PIN lock screen (salted + hashed, stored only on the phone)
- Home dashboard (greeting, progress, tiles) and Urdu/English UI switch (Urdu = right-to-left layout)
- Settings stored with DataStore

## Part A1
- Project setup (Gradle, Compose, Material 3, Navigation, Room)
- Theme (navy / emerald / gold / warm white, light + dark)
- Room database (chapters, headings, lesson sections, questions, quiz attempts, progress, bookmarks, notes)
- Import of `app/src/main/assets/master_outline.json` (chapter > sub-heading > topic) into the database
- Temporary screens: chapter list and chapter detail (to check the outline on a real phone)

## Build
- GitHub: upload `app.zip` to the repo root (see `build-apk.yml`); the APK appears under Actions > Artifacts.
- Android Studio: open this folder, let it sync, run `app`.
