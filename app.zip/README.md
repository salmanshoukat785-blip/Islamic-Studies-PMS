# Islamic Studies Academy (Android)

Kotlin + Jetpack Compose, 100% offline, Urdu + English.

## Part A1 (this version)
- Project setup (Gradle, Compose, Material 3, Navigation, Room)
- Theme (navy / emerald / gold / warm white, light + dark)
- Room database (chapters, headings, lesson sections, questions, quiz attempts, progress, bookmarks, notes)
- Import of `app/src/main/assets/master_outline.json` (chapter > sub-heading > topic) into the database
- Temporary screens: chapter list and chapter detail (to check the outline on a real phone)

## Build
- GitHub: upload `app.zip` to the repo root (see `build-apk.yml`); the APK appears under Actions > Artifacts.
- Android Studio: open this folder, let it sync, run `app`.
