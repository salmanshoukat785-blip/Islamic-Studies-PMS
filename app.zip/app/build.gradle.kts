plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

fun envOr(name: String, fallback: String): String {
    val value = System.getenv(name)
    return if (value.isNullOrBlank()) fallback else value
}

android {
    namespace = "com.islamicstudies.academy"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.islamicstudies.academy"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "0.9.0"
    }

    signingConfigs {
        // One stable key for debug and release builds, so every new APK installs over the previous one.
        // GitHub Secrets (ANDROID_KEYSTORE_*) override it for a real release key. See RELEASE.md.
        create("shared") {
            storeFile = file(envOr("ANDROID_KEYSTORE_FILE", "signing/test-key.jks"))
            storeType = "pkcs12"
            storePassword = envOr("ANDROID_KEYSTORE_PASSWORD", "pQTRVTgDg3V8BW1cLw2u")
            keyAlias = envOr("ANDROID_KEY_ALIAS", "academy")
            keyPassword = envOr("ANDROID_KEY_PASSWORD", "pQTRVTgDg3V8BW1cLw2u")
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            signingConfig = signingConfigs.getByName("shared")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.navigation:navigation-compose:2.8.0")

    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")

    implementation("androidx.datastore:datastore-preferences:1.1.1")

    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")
}
