package com.islamicstudies.academy.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke

/** A simple open-book icon drawn with shapes (no icon library needed). */
@Composable
fun BookIcon(modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
        val corner = CornerRadius(w * 0.08f, w * 0.08f)
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.08f, h * 0.2f),
            size = Size(w * 0.4f, h * 0.6f),
            cornerRadius = corner,
            style = stroke
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.52f, h * 0.2f),
            size = Size(w * 0.4f, h * 0.6f),
            cornerRadius = corner,
            style = stroke
        )
        drawLine(color, Offset(w * 0.18f, h * 0.38f), Offset(w * 0.38f, h * 0.38f), strokeWidth = w * 0.06f, cap = StrokeCap.Round)
        drawLine(color, Offset(w * 0.18f, h * 0.52f), Offset(w * 0.38f, h * 0.52f), strokeWidth = w * 0.06f, cap = StrokeCap.Round)
        drawLine(color, Offset(w * 0.62f, h * 0.38f), Offset(w * 0.82f, h * 0.38f), strokeWidth = w * 0.06f, cap = StrokeCap.Round)
        drawLine(color, Offset(w * 0.62f, h * 0.52f), Offset(w * 0.82f, h * 0.52f), strokeWidth = w * 0.06f, cap = StrokeCap.Round)
    }
}

/** A crescent drawn with two circles; used in headers. */
@Composable
fun CrescentIcon(modifier: Modifier = Modifier, color: Color, cutout: Color) {
    Canvas(modifier = modifier) {
        val r = size.minDimension
        drawCircle(color = color, radius = r * 0.36f, center = Offset(size.width * 0.5f, size.height * 0.5f))
        drawCircle(color = cutout, radius = r * 0.31f, center = Offset(size.width * 0.6f, size.height * 0.44f))
    }
}
