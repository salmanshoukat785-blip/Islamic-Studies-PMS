package com.islamicstudies.academy.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.islamicstudies.academy.AcademyApp
import com.islamicstudies.academy.data.settings.AppSettings
import com.islamicstudies.academy.ui.chapters.ChapterDetailScreen
import com.islamicstudies.academy.ui.chapters.ChaptersScreen
import com.islamicstudies.academy.ui.home.HomeScreen
import com.islamicstudies.academy.ui.lock.LockScreen
import com.islamicstudies.academy.ui.onboarding.OnboardingScreen
import com.islamicstudies.academy.ui.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOCK = "lock"
    const val HOME = "home"
    const val CHAPTERS = "chapters"
    const val CHAPTER = "chapter/{chapterId}"
    fun chapter(id: String) = "chapter/$id"
}

@Composable
fun AppNavHost(settings: AppSettings) {
    val navController = rememberNavController()
    val app = LocalContext.current.applicationContext as AcademyApp

    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    val destination = when {
                        !settings.onboardingDone -> Routes.ONBOARDING
                        settings.pinEnabled && !app.sessionUnlocked -> Routes.LOCK
                        else -> Routes.HOME
                    }
                    navController.navigate(destination) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.LOCK) {
            LockScreen(
                onUnlocked = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOCK) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(onOpenChapters = { navController.navigate(Routes.CHAPTERS) })
        }
        composable(Routes.CHAPTERS) {
            ChaptersScreen(
                onBack = { navController.popBackStack() },
                onOpenChapter = { id -> navController.navigate(Routes.chapter(id)) }
            )
        }
        composable(
            route = Routes.CHAPTER,
            arguments = listOf(navArgument("chapterId") { type = NavType.StringType })
        ) {
            ChapterDetailScreen(onBack = { navController.popBackStack() })
        }
    }
}
