package com.islamicstudies.academy.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.islamicstudies.academy.ui.chapters.ChapterDetailScreen
import com.islamicstudies.academy.ui.chapters.ChaptersScreen

object Routes {
    const val CHAPTERS = "chapters"
    const val CHAPTER = "chapter/{chapterId}"
    fun chapter(id: String) = "chapter/$id"
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.CHAPTERS) {
        composable(Routes.CHAPTERS) {
            ChaptersScreen(onOpenChapter = { id -> navController.navigate(Routes.chapter(id)) })
        }
        composable(
            route = Routes.CHAPTER,
            arguments = listOf(navArgument("chapterId") { type = NavType.StringType })
        ) {
            ChapterDetailScreen(onBack = { navController.popBackStack() })
        }
    }
}
