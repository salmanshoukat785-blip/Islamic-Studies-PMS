package com.islamicstudies.academy.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom

data class AppSettings(
    val loaded: Boolean = false,
    val language: String = "ur",       // "ur" or "en"
    val onboardingDone: Boolean = false,
    val name: String = "",
    val level: String = "basic",       // "basic", "intermediate", "advanced"
    val pinEnabled: Boolean = false,
    val theme: String = "system",       // "system", "light", "dark"
    val textScalePercent: Int = 100,    // 80..160
    val contentLanguage: String = ""    // "" = follow app language, or "ur", "en", "both"
)

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

private object Keys {
    val LANGUAGE = stringPreferencesKey("language")
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    val NAME = stringPreferencesKey("name")
    val LEVEL = stringPreferencesKey("level")
    val PIN_SALT = stringPreferencesKey("pin_salt")
    val PIN_HASH = stringPreferencesKey("pin_hash")
    val THEME = stringPreferencesKey("theme")
    val TEXT_SCALE = intPreferencesKey("text_scale")
    val CONTENT_LANGUAGE = stringPreferencesKey("content_language")
}

/** Local app lock helper. The PIN is only a privacy lock on the phone; it is stored salted and hashed. */
object PinHasher {
    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return toHex(bytes)
    }

    fun hash(pin: String, salt: String): String {
        var current = (salt + pin).toByteArray(Charsets.UTF_8)
        repeat(10_000) {
            current = MessageDigest.getInstance("SHA-256").digest(current)
        }
        return toHex(current)
    }

    private fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }
}

class SettingsRepository(context: Context) {

    private val store: DataStore<Preferences> = context.applicationContext.settingsDataStore

    val settings: Flow<AppSettings> = store.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { p ->
            AppSettings(
                loaded = true,
                language = p[Keys.LANGUAGE] ?: "ur",
                onboardingDone = p[Keys.ONBOARDING_DONE] ?: false,
                name = p[Keys.NAME] ?: "",
                level = p[Keys.LEVEL] ?: "basic",
                pinEnabled = p[Keys.PIN_HASH] != null,
                theme = p[Keys.THEME] ?: "system",
                textScalePercent = p[Keys.TEXT_SCALE] ?: 100,
                contentLanguage = p[Keys.CONTENT_LANGUAGE] ?: ""
            )
        }

    suspend fun setLanguage(language: String) {
        store.edit { p -> p[Keys.LANGUAGE] = language }
    }

    suspend fun setLevel(level: String) {
        store.edit { p -> p[Keys.LEVEL] = level }
    }

    suspend fun setTheme(theme: String) {
        store.edit { p -> p[Keys.THEME] = theme }
    }

    suspend fun setTextScale(percent: Int) {
        store.edit { p -> p[Keys.TEXT_SCALE] = percent }
    }

    suspend fun setContentLanguage(language: String) {
        store.edit { p -> p[Keys.CONTENT_LANGUAGE] = language }
    }

    suspend fun completeOnboarding(name: String, level: String, pin: String?) {
        store.edit { p ->
            p[Keys.NAME] = name
            p[Keys.LEVEL] = level
            if (pin != null) {
                val salt = PinHasher.newSalt()
                p[Keys.PIN_SALT] = salt
                p[Keys.PIN_HASH] = PinHasher.hash(pin, salt)
            } else {
                p.remove(Keys.PIN_SALT)
                p.remove(Keys.PIN_HASH)
            }
            p[Keys.ONBOARDING_DONE] = true
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val p = store.data.first()
        val salt = p[Keys.PIN_SALT]
        val hash = p[Keys.PIN_HASH]
        if (salt == null || hash == null) return true
        return PinHasher.hash(pin, salt) == hash
    }
}
