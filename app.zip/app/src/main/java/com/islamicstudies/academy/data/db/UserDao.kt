package com.islamicstudies.academy.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class SavedItem(
    val headingId: String,
    val titleUr: String,
    val titleEn: String,
    val chapterTitleUr: String,
    val chapterTitleEn: String
)

data class NoteItem(
    val headingId: String,
    val titleUr: String,
    val titleEn: String,
    val chapterTitleUr: String,
    val chapterTitleEn: String,
    val noteText: String
)

@Dao
interface UserDao {

    // ---- progress overview ----
    @Query(
        "SELECT COUNT(*) FROM user_progress p JOIN headings h ON h.id = p.headingId " +
            "WHERE p.completed = 1 AND h.type = 'topic'"
    )
    fun observeCompletedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM headings WHERE type = 'topic'")
    fun observeTopicCount(): Flow<Int>

    @Query("SELECT headingId FROM bookmarks")
    fun observeBookmarkIds(): Flow<List<String>>

    @Query("SELECT headingId FROM user_progress WHERE completed = 1")
    fun observeCompletedIds(): Flow<List<String>>

    // ---- single lesson state ----
    @Query("SELECT COUNT(*) FROM bookmarks WHERE headingId = :id")
    fun observeBookmarkCount(id: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM user_progress WHERE headingId = :id AND completed = 1")
    fun observeCompletedFlag(id: String): Flow<Int>

    @Query("SELECT text FROM personal_notes WHERE headingId = :id")
    fun observeNote(id: String): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBookmark(item: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE headingId = :id")
    suspend fun removeBookmark(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(item: PersonalNoteEntity)

    @Query("DELETE FROM personal_notes WHERE headingId = :id")
    suspend fun deleteNote(id: String)

    @Query("SELECT * FROM user_progress WHERE headingId = :id")
    suspend fun getProgress(id: String): UserProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(item: UserProgressEntity)

    // ---- lists ----
    @Query(
        "SELECT h.id AS headingId, h.titleUr AS titleUr, h.titleEn AS titleEn, " +
            "c.titleUr AS chapterTitleUr, c.titleEn AS chapterTitleEn " +
            "FROM bookmarks b JOIN headings h ON h.id = b.headingId " +
            "JOIN chapters c ON c.id = h.chapterId ORDER BY b.createdAt DESC"
    )
    fun observeBookmarks(): Flow<List<SavedItem>>

    @Query(
        "SELECT h.id AS headingId, h.titleUr AS titleUr, h.titleEn AS titleEn, " +
            "c.titleUr AS chapterTitleUr, c.titleEn AS chapterTitleEn, n.text AS noteText " +
            "FROM personal_notes n JOIN headings h ON h.id = n.headingId " +
            "JOIN chapters c ON c.id = h.chapterId ORDER BY n.updatedAt DESC"
    )
    fun observeNotes(): Flow<List<NoteItem>>

    @Query(
        "SELECT h.id AS headingId, h.titleUr AS titleUr, h.titleEn AS titleEn, " +
            "c.titleUr AS chapterTitleUr, c.titleEn AS chapterTitleEn " +
            "FROM user_progress p JOIN headings h ON h.id = p.headingId " +
            "JOIN chapters c ON c.id = h.chapterId ORDER BY p.lastOpenedAt DESC LIMIT 1"
    )
    fun observeLastOpened(): Flow<SavedItem?>
}
