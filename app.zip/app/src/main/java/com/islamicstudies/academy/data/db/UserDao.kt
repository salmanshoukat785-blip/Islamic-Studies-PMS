package com.islamicstudies.academy.data.db

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT COUNT(*) FROM user_progress WHERE completed = 1")
    fun observeCompletedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM headings WHERE type = 'topic'")
    fun observeTopicCount(): Flow<Int>
}
