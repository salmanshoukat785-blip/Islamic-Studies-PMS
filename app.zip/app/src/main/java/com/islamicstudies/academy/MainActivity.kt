package com.islamicstudies.academy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.islamicstudies.academy.ui.AppRoot
import com.islamicstudies.academy.ui.theme.AcademyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AcademyTheme {
                AppRoot()
            }
        }
    }
}
