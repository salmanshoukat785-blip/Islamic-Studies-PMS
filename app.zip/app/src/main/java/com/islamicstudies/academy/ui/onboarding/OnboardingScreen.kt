package com.islamicstudies.academy.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.islamicstudies.academy.ui.EnStrings
import com.islamicstudies.academy.ui.LocalAppLanguage
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.UrStrings
import com.islamicstudies.academy.ui.components.BookIcon
import com.islamicstudies.academy.ui.components.ChoiceCard
import com.islamicstudies.academy.ui.components.CrescentIcon
import com.islamicstudies.academy.ui.theme.Gold
import com.islamicstudies.academy.ui.theme.HeaderTeal
import com.islamicstudies.academy.ui.theme.Navy
import com.islamicstudies.academy.ui.theme.UrduText

private const val STEP_LANGUAGE = 0
private const val STEP_PROFILE = 4
private const val LAST_STEP = 4

@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    viewModel: OnboardingViewModel = viewModel()
) {
    val s = LocalStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var step by rememberSaveable { mutableIntStateOf(STEP_LANGUAGE) }
    var name by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf("basic") }

    Column(modifier = Modifier.fillMaxSize()) {
        Header(step = step)

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (step) {
                STEP_LANGUAGE -> LanguageStep(
                    selected = settings.language,
                    onSelect = { lang -> viewModel.setLanguage(lang) }
                )
                1 -> IntroStep(1, s.intro1Title, s.intro1Body)
                2 -> IntroStep(2, s.intro2Title, s.intro2Body)
                3 -> IntroStep(3, s.intro3Title, s.intro3Body)
                else -> ProfileStep(
                    name = name,
                    onNameChange = { v -> name = v },
                    level = level,
                    onLevelChange = { v -> level = v }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (step > STEP_LANGUAGE) {
                TextButton(onClick = { step -= 1 }) { Text(s.back) }
            } else {
                Spacer(modifier = Modifier.width(1.dp))
            }

            if (step == LAST_STEP) {
                Button(
                    onClick = { viewModel.finish(name, level, onFinished) },
                    shape = RoundedCornerShape(50)
                ) { Text(s.getStarted, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) }
            } else {
                Button(
                    onClick = { step += 1 },
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = if (step == STEP_LANGUAGE) s.continueLabel else s.next,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun Header(step: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(Navy, HeaderTeal)),
                RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
            )
            .padding(top = 28.dp, bottom = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CrescentIcon(modifier = Modifier.size(84.dp), color = Gold, cutout = Navy)
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = UrStrings.appName, style = UrduText.title, color = Color.White)
            Text(
                text = EnStrings.appName,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in 0..LAST_STEP) {
                    Box(
                        modifier = Modifier
                            .size(width = if (i == step) 22.dp else 8.dp, height = 8.dp)
                            .background(
                                if (i == step) Gold else Color.White.copy(alpha = 0.4f),
                                RoundedCornerShape(50)
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageStep(selected: String, onSelect: (String) -> Unit) {
    val s = LocalStrings.current
    Text(
        text = s.chooseLanguage,
        style = MaterialTheme.typography.titleLarge,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(24.dp))
    ChoiceCard(
        label = "اردو",
        selected = selected == "ur",
        onClick = { onSelect("ur") },
        textStyle = UrduText.title
    )
    Spacer(modifier = Modifier.height(12.dp))
    ChoiceCard(
        label = "English",
        selected = selected == "en",
        onClick = { onSelect("en") }
    )
}

@Composable
private fun IntroStep(number: Int, title: String, body: String) {
    val isUrdu = LocalAppLanguage.current == "ur"
    Box(
        modifier = Modifier
            .size(88.dp)
            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        when (number) {
            1 -> BookIcon(modifier = Modifier.size(44.dp), color = MaterialTheme.colorScheme.primary)
            2 -> Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
            else -> Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
        }
    }
    Spacer(modifier = Modifier.height(24.dp))
    Text(
        text = title,
        style = if (isUrdu) UrduText.title else MaterialTheme.typography.headlineSmall,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(12.dp))
    Text(
        text = body,
        style = if (isUrdu) UrduText.body else MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
    )
}

@Composable
private fun ProfileStep(
    name: String,
    onNameChange: (String) -> Unit,
    level: String,
    onLevelChange: (String) -> Unit
) {
    val s = LocalStrings.current
    Text(
        text = s.profileTitle,
        style = MaterialTheme.typography.titleLarge,
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(20.dp))
    OutlinedTextField(
        value = name,
        onValueChange = onNameChange,
        label = { Text(s.nameHint) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(24.dp))
    Text(
        text = s.levelTitle,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(8.dp))
    ChoiceCard(label = s.levelBasic, selected = level == "basic", onClick = { onLevelChange("basic") })
    Spacer(modifier = Modifier.height(8.dp))
    ChoiceCard(
        label = s.levelIntermediate,
        selected = level == "intermediate",
        onClick = { onLevelChange("intermediate") }
    )
    Spacer(modifier = Modifier.height(8.dp))
    ChoiceCard(
        label = s.levelAdvanced,
        selected = level == "advanced",
        onClick = { onLevelChange("advanced") }
    )
}
