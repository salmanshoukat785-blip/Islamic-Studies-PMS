package com.islamicstudies.academy.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.islamicstudies.academy.ui.LocalAppLanguage
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.components.AcademyBottomBar
import com.islamicstudies.academy.ui.isEnglishPrimary
import com.islamicstudies.academy.ui.pickTitle
import com.islamicstudies.academy.ui.theme.Gold
import com.islamicstudies.academy.ui.theme.UrduText

@Composable
fun HomeScreen(
    onOpenChapters: () -> Unit,
    onOpenChapter: (String) -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenLesson: (String) -> Unit,
    onOpenQuiz: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onTab: (String) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val s = LocalStrings.current
    val uiLang = LocalAppLanguage.current
    val isUrdu = uiLang == "ur"
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }

    val fraction = if (ui.total > 0) ui.completed.toFloat() / ui.total.toFloat() else 0f
    val totalHeadings = ui.chapters.sumOf { c -> c.headingCount }
    val last = ui.lastOpened

    Scaffold(
        bottomBar = { AcademyBottomBar(current = "home", onTab = onTab) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // ---- header with the stats card overlapping its lower edge ----
            Box(modifier = Modifier.fillMaxWidth().height(318.dp)) {
                HeaderArt(modifier = Modifier.fillMaxWidth().height(250.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.Menu, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(s.tileQuiz) },
                                onClick = { menuOpen = false; onOpenQuiz() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.tileSearch) },
                                onClick = { menuOpen = false; onOpenSearch() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.tileBookmarks) },
                                onClick = { menuOpen = false; onOpenBookmarks() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.tileNotes) },
                                onClick = { menuOpen = false; onOpenNotes() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.langToggleLabel) },
                                onClick = { menuOpen = false; viewModel.toggleLanguage() }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Notifications, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, end = 24.dp, top = 70.dp)
                ) {
                    Text(
                        text = s.headerTitle,
                        color = Color.White,
                        fontSize = if (isUrdu) 36.sp else 40.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = if (isUrdu) FontFamily.Default else FontFamily.Serif
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = s.headerTagline,
                        color = Gold,
                        fontSize = if (isUrdu) 18.sp else 20.sp,
                        fontStyle = if (isUrdu) FontStyle.Normal else FontStyle.Italic,
                        fontFamily = if (isUrdu) FontFamily.Default else FontFamily.Serif
                    )
                }

                StatsCard(
                    chapters = ui.chapters.size,
                    headings = totalHeadings,
                    fraction = fraction,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp)
                )
            }

            // ---- continue card + chapter list ----
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (last != null) {
                    val lastEnglish = isEnglishPrimary(last.titleEn, uiLang)
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenLesson(last.headingId) },
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(34.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = s.continueLearning,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = pickTitle(last.titleUr, last.titleEn, uiLang),
                                    style = if (lastEnglish) MaterialTheme.typography.titleMedium else UrduText.subheading,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                for (chapter in ui.chapters) {
                    ChapterRowCard(chapter = chapter, onClick = { onOpenChapter(chapter.id) })
                }

                QuoteBanner(text = s.quoteText)
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}
