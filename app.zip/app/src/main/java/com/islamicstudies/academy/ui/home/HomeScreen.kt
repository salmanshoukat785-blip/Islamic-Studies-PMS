package com.islamicstudies.academy.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.islamicstudies.academy.ui.LocalAppLanguage
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.components.BookIcon
import com.islamicstudies.academy.ui.isEnglishPrimary
import com.islamicstudies.academy.ui.pickTitle
import com.islamicstudies.academy.ui.theme.Gold
import com.islamicstudies.academy.ui.theme.HeaderTeal
import com.islamicstudies.academy.ui.theme.Navy
import com.islamicstudies.academy.ui.theme.UrduText

private data class Tile(
    val label: String,
    val accent: Color,
    val onClick: () -> Unit,
    val icon: @Composable (Color) -> Unit
)

@Composable
fun HomeScreen(
    onOpenChapters: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenLesson: (String) -> Unit,
    onOpenQuiz: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenProgress: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val s = LocalStrings.current
    val uiLang = LocalAppLanguage.current
    val ui by viewModel.ui.collectAsStateWithLifecycle()

    val levelLabel = when (ui.settings.level) {
        "intermediate" -> s.levelIntermediate
        "advanced" -> s.levelAdvanced
        else -> s.levelBasic
    }
    val fraction = if (ui.total > 0) ui.completed.toFloat() / ui.total.toFloat() else 0f
    val last = ui.lastOpened

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary

    val tiles = listOf(
        Tile(s.tileChapters, primary, onOpenChapters) { c ->
            BookIcon(modifier = Modifier.size(26.dp), color = c)
        },
        Tile(s.tileQuiz, secondary, onOpenQuiz) { c ->
            Icon(imageVector = Icons.Filled.CheckCircle, contentDescription = null, tint = c)
        },
        Tile(s.tileBookmarks, tertiary, onOpenBookmarks) { c ->
            Icon(imageVector = Icons.Filled.Star, contentDescription = null, tint = c)
        },
        Tile(s.tileNotes, primary, onOpenNotes) { c ->
            Icon(imageVector = Icons.Filled.Edit, contentDescription = null, tint = c)
        },
        Tile(s.tileSearch, secondary, onOpenSearch) { c ->
            Icon(imageVector = Icons.Filled.Search, contentDescription = null, tint = c)
        },
        Tile(s.tileSettings, tertiary, onOpenSettings) { c ->
            Icon(imageVector = Icons.Filled.Settings, contentDescription = null, tint = c)
        }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        HomeHeader(
            name = ui.settings.name,
            levelLabel = levelLabel,
            onToggleLanguage = { viewModel.toggleLanguage() }
        )

        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main call to action
            if (last != null) {
                val lastEnglish = isEnglishPrimary(last.titleEn, uiLang)
                ActionCard(
                    label = s.continueLearning,
                    title = pickTitle(last.titleUr, last.titleEn, uiLang),
                    subtitle = pickTitle(last.chapterTitleUr, last.chapterTitleEn, uiLang),
                    titleIsEnglish = lastEnglish,
                    onClick = { onOpenLesson(last.headingId) }
                )
            } else {
                ActionCard(
                    label = s.startLearning,
                    title = s.startLearningHint,
                    subtitle = "",
                    titleIsEnglish = uiLang == "en",
                    onClick = onOpenChapters
                )
            }

            // Progress
            Card(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenProgress),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ProgressRing(
                        fraction = fraction,
                        ringSize = 84.dp,
                        track = MaterialTheme.colorScheme.surfaceVariant,
                        color = secondary,
                        label = (fraction * 100).toInt().toString() + "%"
                    )
                    Spacer(modifier = Modifier.width(18.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = s.progressTitle,
                            style = if (uiLang == "ur") UrduText.subheading else MaterialTheme.typography.titleMedium,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = s.progressText(ui.completed, ui.total),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Shortcuts
            for (rowTiles in tiles.chunked(2)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    for (tile in rowTiles) {
                        TileCard(tile = tile, modifier = Modifier.weight(1f))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun HomeHeader(name: String, levelLabel: String, onToggleLanguage: () -> Unit) {
    val s = LocalStrings.current
    val isUrdu = LocalAppLanguage.current == "ur"
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(Navy, HeaderTeal)),
                RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
            )
    ) {
        Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 26.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = s.appName,
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    color = Color.White.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onToggleLanguage)
                ) {
                    Text(
                        text = s.langToggleLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(26.dp))
            Text(
                text = s.greeting(name),
                style = if (isUrdu) {
                    UrduText.title.copy(fontSize = 26.sp, lineHeight = 44.sp)
                } else {
                    MaterialTheme.typography.headlineMedium
                },
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = s.tagline,
                style = if (isUrdu) UrduText.body else MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(14.dp))
            Surface(
                color = Gold.copy(alpha = 0.22f),
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    text = levelLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = Gold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun ActionCard(
    label: String,
    title: String,
    subtitle: String,
    titleIsEnglish: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(MaterialTheme.colorScheme.secondary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSecondary,
                    modifier = Modifier.size(30.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = title,
                    style = if (titleIsEnglish) MaterialTheme.typography.titleMedium else UrduText.subheading,
                    modifier = Modifier.fillMaxWidth()
                )
                if (subtitle.isNotBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun ProgressRing(fraction: Float, ringSize: Dp, track: Color, color: Color, label: String) {
    Box(modifier = Modifier.size(ringSize), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 10.dp.toPx()
            val inset = strokeWidth / 2f
            val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
            val style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            drawArc(
                color = track,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = style
            )
            if (fraction > 0f) {
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = 360f * fraction,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = style
                )
            }
        }
        Text(text = label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TileCard(tile: Tile, modifier: Modifier = Modifier) {
    val isUrdu = LocalAppLanguage.current == "ur"
    Card(
        modifier = modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = tile.onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 22.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(tile.accent.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                tile.icon(tile.accent)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = tile.label,
                style = if (isUrdu) UrduText.subheading else MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
        }
    }
}
