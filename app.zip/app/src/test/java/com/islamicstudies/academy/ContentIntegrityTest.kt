package com.islamicstudies.academy

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Checks the course files in src/main/assets. Run these tests after adding lesson or question
 * files: they catch wrong ids, missing options and similar mistakes before the app does.
 */
class ContentIntegrityTest {

    private fun read(path: String): JSONObject =
        JSONObject(File(path).readText(Charsets.UTF_8))

    private fun collectIds(children: JSONArray?, out: MutableList<String>) {
        if (children == null) return
        for (i in 0 until children.length()) {
            val n = children.getJSONObject(i)
            out.add(n.getString("id"))
            assertTrue("empty title in " + n.getString("id"), n.getString("title").isNotBlank())
            val type = n.getString("type")
            assertTrue("bad type $type", type == "subheading" || type == "topic")
            collectIds(n.optJSONArray("children"), out)
        }
    }

    private fun outlineIds(): Pair<List<String>, List<String>> {
        val chapters = read("src/main/assets/master_outline.json").getJSONArray("chapters")
        val chapterIds = ArrayList<String>()
        val allIds = ArrayList<String>()
        for (i in 0 until chapters.length()) {
            val c = chapters.getJSONObject(i)
            chapterIds.add(c.getString("id"))
            allIds.add(c.getString("id"))
            assertTrue(c.getString("title").isNotBlank())
            collectIds(c.optJSONArray("children"), allIds)
        }
        return Pair(chapterIds, allIds)
    }

    @Test
    fun outlineHasEighteenChaptersAndUniqueIds() {
        val (chapterIds, allIds) = outlineIds()
        assertEquals(18, chapterIds.size)
        assertEquals("duplicate ids in the outline", allIds.size, allIds.toSet().size)
    }

    @Test
    fun lessonFilesPointToRealHeadings() {
        val (_, allIds) = outlineIds()
        val ids = allIds.toSet()
        val dir = File("src/main/assets/content")
        val levels = setOf("basic", "intermediate", "advanced")
        val kinds = setOf("text", "point", "reference")
        for (file in dir.listFiles()?.filter { f -> f.name.endsWith(".json") } ?: emptyList()) {
            val lessons = read(file.path).getJSONArray("lessons")
            for (i in 0 until lessons.length()) {
                val lesson = lessons.getJSONObject(i)
                val headingId = lesson.getString("headingId")
                assertTrue("unknown heading $headingId in ${file.name}", ids.contains(headingId))
                val sections = lesson.getJSONArray("sections")
                for (j in 0 until sections.length()) {
                    val sec = sections.getJSONObject(j)
                    assertTrue(setOf("ur", "en").contains(sec.getString("lang")))
                    assertTrue(levels.contains(sec.getString("level")))
                    assertTrue(kinds.contains(sec.optString("kind", "text")))
                    assertTrue(sec.getString("body").isNotBlank())
                }
            }
        }
    }

    @Test
    fun questionFilesAreValid() {
        val (chapterIds, allIds) = outlineIds()
        val chapters = chapterIds.toSet()
        val headings = allIds.toSet()
        val seen = HashSet<String>()
        val difficulties = setOf("basic", "intermediate", "advanced")
        val dir = File("src/main/assets/questions")
        for (file in dir.listFiles()?.filter { f -> f.name.endsWith(".json") } ?: emptyList()) {
            val questions = read(file.path).getJSONArray("questions")
            for (i in 0 until questions.length()) {
                val q = questions.getJSONObject(i)
                val id = q.getString("id")
                assertTrue("duplicate question id $id", seen.add(id))
                assertTrue("unknown chapter in $id", chapters.contains(q.getString("chapterId")))
                val headingId = q.optString("headingId", "")
                assertTrue("unknown heading in $id", headingId.isEmpty() || headings.contains(headingId))
                assertTrue("bad difficulty in $id", difficulties.contains(q.getString("difficulty")))
                val ur = q.getJSONArray("optionsUr")
                val en = q.getJSONArray("optionsEn")
                assertEquals("option counts differ in $id", ur.length(), en.length())
                assertTrue("need at least 2 options in $id", ur.length() >= 2)
                val correct = q.getInt("correctIndex")
                assertTrue("correctIndex out of range in $id", correct >= 0 && correct < ur.length())
                assertTrue("empty question text in $id", q.getString("textUr").isNotBlank() || q.getString("textEn").isNotBlank())
            }
        }
    }
}
