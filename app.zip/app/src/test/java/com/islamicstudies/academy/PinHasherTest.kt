package com.islamicstudies.academy

import com.islamicstudies.academy.data.settings.PinHasher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class PinHasherTest {

    @Test
    fun sameInputGivesSameHash() {
        val salt = PinHasher.newSalt()
        assertEquals(PinHasher.hash("1234", salt), PinHasher.hash("1234", salt))
    }

    @Test
    fun differentPinOrSaltChangesHash() {
        val salt = PinHasher.newSalt()
        assertNotEquals(PinHasher.hash("1234", salt), PinHasher.hash("1235", salt))
        assertNotEquals(PinHasher.hash("1234", salt), PinHasher.hash("1234", PinHasher.newSalt()))
    }

    @Test
    fun hashIsSha256HexAndSaltIs16Bytes() {
        val salt = PinHasher.newSalt()
        assertEquals(32, salt.length)
        assertEquals(64, PinHasher.hash("0000", salt).length)
    }
}
