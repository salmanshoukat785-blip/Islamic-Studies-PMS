package com.islamicstudies.academy

import com.islamicstudies.academy.data.db.QuestionEntity
import com.islamicstudies.academy.data.settings.AppSettings
import com.islamicstudies.academy.ui.components.contentLanguages
import com.islamicstudies.academy.ui.components.linesFor
import com.islamicstudies.academy.ui.quiz.formatSeconds
import com.islamicstudies.academy.ui.quiz.optionsFor
import org.junit.Assert.assertEquals
import org.junit.Test

class HelpersTest {

    @Test
    fun formatSecondsShowsMinutesAndSeconds() {
        assertEquals("0:00", formatSeconds(0))
        assertEquals("0:09", formatSeconds(9))
        assertEquals("1:05", formatSeconds(65))
        assertEquals("0:00", formatSeconds(-3))
    }

    @Test
    fun linesForUsesWantedLanguagesInOrder() {
        val lines = linesFor("اردو", "English", listOf("ur", "en"))
        assertEquals(listOf(Pair("ur", "اردو"), Pair("en", "English")), lines)
        assertEquals(listOf(Pair("en", "English")), linesFor("اردو", "English", listOf("en")))
    }

    @Test
    fun linesForFallsBackToAvailableText() {
        assertEquals(listOf(Pair("ur", "اردو")), linesFor("اردو", "", listOf("en")))
        assertEquals(listOf(Pair("en", "English")), linesFor("", "English", listOf("ur")))
    }

    @Test
    fun contentLanguagesFollowsSettingsOrAppLanguage() {
        assertEquals(listOf("en"), contentLanguages(AppSettings(contentLanguage = ""), "en"))
        assertEquals(listOf("ur"), contentLanguages(AppSettings(contentLanguage = "ur"), "en"))
        assertEquals(listOf("ur", "en"), contentLanguages(AppSettings(contentLanguage = "both"), "en"))
    }

    @Test
    fun questionOptionsAreReadFromJson() {
        val q = QuestionEntity(
            id = "t1", chapterId = "ch01", headingId = "", difficulty = "basic",
            textUr = "", textEn = "",
            optionsUrJson = "[\"a\",\"b\"]", optionsEnJson = "not json",
            correctIndex = 0, explanationUr = "", explanationEn = ""
        )
        assertEquals(listOf("a", "b"), q.optionsFor("ur"))
        assertEquals(emptyList<String>(), q.optionsFor("en"))
    }
}
