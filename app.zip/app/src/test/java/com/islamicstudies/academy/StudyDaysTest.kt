package com.islamicstudies.academy

import com.islamicstudies.academy.data.settings.currentStreak
import com.islamicstudies.academy.data.settings.localEpochDay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StudyDaysTest {

    @Test
    fun streakCountsConsecutiveDaysEndingToday() {
        val days = setOf(10L, 11L, 12L)
        assertEquals(3, currentStreak(days, 12L))
    }

    @Test
    fun streakContinuesWhenTodayIsNotStudiedYet() {
        val days = setOf(10L, 11L)
        assertEquals(2, currentStreak(days, 12L))
    }

    @Test
    fun streakBreaksAfterAGap() {
        val days = setOf(5L, 6L, 9L)
        assertEquals(0, currentStreak(days, 12L))
        assertEquals(1, currentStreak(days, 9L))
    }

    @Test
    fun streakIsZeroWithoutStudy() {
        assertEquals(0, currentStreak(emptySet(), 12L))
    }

    @Test
    fun epochDayIsPlausible() {
        // 2026 is well after day 20000 (about 2024-10-04) and before day 30000.
        val today = localEpochDay()
        assertTrue(today > 20000L && today < 30000L)
    }
}
